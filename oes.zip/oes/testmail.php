
<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
include('dbConnection.php');
date_default_timezone_set("Asia/Kolkata");

require 'PHPMailer/vendor/autoload.php';


//$name = $_POST['name'];
$name = $_SESSION['car1'];
//$gender = $_POST['gender'];
$gender = $_SESSION['car2'];
//$x = $_POST['email'];
$x=$_SESSION['car'];
//$college = $_POST['college'];
$college = $_SESSION['car3'];
//$mob = $_POST['mob'];
$mob = $_SESSION['car4'];
//$password = $_POST['password'];
$password = $_SESSION['car5'];



$var1=rand(100000,999999);
$result=mysqli_query($con," insert into otp_expiry(id,otp,create_at,is_expired,email)values('','".$var1."','".date("Y-m-d H:i:s")."',0,'".$x."') ");
$mail = new PHPMailer();

$_SESSION['var1']=$x;
$_SESSION['var2']=$name;
$_SESSION['var3']=$gender;
$_SESSION['var4']=$college;
$_SESSION['var5']=$mob;
$_SESSION['var6']=$password;


$mail->isSMTP(); 
$mail->SMTPAuth = true;                                     // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com'; 
$mail->SMTPDebug = 0;                      // Specify main and backup server
$mail->Username = 'oexamination4@gmail.com';                   // SMTP username
$mail->Password = 'Kavya@123';
$mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 587;                                    //Set the SMTP port number - 587 for authenticated TLS
//$mail->setFrom('icmsiiitbh@gmail.com', 'ICMS IIIT Bhagalpur');     //Set who the message is to be sent from
$mail->setFrom('oexamination4@gmail.com', 'Online Examination System');

//$mail->addReplyTo('labnol@gmail.com', 'First Last');  //Set an alternative reply-to address
//$mail->addAddress('surajfake1122@gmail.com', 'duggu');
//echo "$x hello";
$mail->addAddress($x,'Kavya');  // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
//$mail->addCC('cc@example.com');
//$mail->addBCC('bcc@example.com');
//$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
//$mail->addAttachment('/usr/labnol/file.doc');         // Add attachments
//$mail->addAttachment('/images/image.jpg', 'new.jpg'); // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'OTP for Registration';
$mail->Body    = 'Dear Student, This is auto generated mail from Katihar Engineering College ,(Online Examination System). Your one time password for creating new account is : '.$var1.'';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));

if(!$mail->send()) {
   echo 'Message could not be sent.';
   header("location:otp_validate.php");
   //echo 'Mailer Error: ' . $mail->ErrorInfo;
   exit;
}
else{
echo 'OTP has been sent';
//header('localhost: http//localhost/cms/send_otp.php');
}
header("location:otp_validate.php");	
				
		//	if($var1==$y){

		//		header('localhost: http//localhost/cms/stud/signup.php');
		//	}
		//	else {

		//		echo "Invalid OTP";
		//	}






?>
